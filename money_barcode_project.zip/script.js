const FIXED_BARCODE = "1234567890128";

function updateDisplay() {
  const amount = localStorage.getItem("money") || "0";
  document.getElementById("amount").textContent = amount;
  JsBarcode("#barcode", FIXED_BARCODE, {
    format: "EAN13",
    displayValue: true
  });
}

function addMoney() {
  const input = document.getElementById("input-amount").value;
  if (!input) return;
  let amount = parseFloat(localStorage.getItem("money") || "0");
  amount += parseFloat(input);
  localStorage.setItem("money", amount.toFixed(2));
  updateDisplay();
}

function spendMoney() {
  const input = document.getElementById("input-amount").value;
  if (!input) return;
  let amount = parseFloat(localStorage.getItem("money") || "0");
  amount -= parseFloat(input);
  if (amount < 0) amount = 0;
  localStorage.setItem("money", amount.toFixed(2));
  updateDisplay();
}

updateDisplay();
