# Money Tracker with Barcode

This is a simple money tracking app using HTML + JS.

- Allows user to input and store money amount (saved in browser localStorage).
- Fixed EAN13 barcode is displayed: `1234567890128`.
- Barcode generated using JsBarcode.

## How to use

1. Open `index.html` in your browser.
2. Enter amount and click "Add Money" or "Spend Money".
3. Amount is updated and saved automatically.
